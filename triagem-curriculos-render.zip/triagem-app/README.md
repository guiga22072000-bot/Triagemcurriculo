# 🔍 Triagem de Currículos com IA

App PWA para triagem automática de currículos usando Claude (Anthropic).

## Deploy no Render.com (passo a passo)

### 1. Subir o código no GitHub
1. Acesse github.com e crie um repositório novo (pode ser privado)
2. Faça upload de todos os arquivos desta pasta

### 2. Criar o serviço no Render
1. Acesse render.com e crie uma conta (grátis)
2. Clique em **New → Web Service**
3. Conecte seu repositório GitHub
4. Configure:
   - **Name:** triagem-curriculos (ou o que quiser)
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. Em **Environment Variables**, adicione:
   - `ANTHROPIC_API_KEY` = sua chave de https://console.anthropic.com
6. Clique em **Create Web Service**

### 3. Usar no celular
1. Abra o link gerado pelo Render no Chrome (Android) ou Safari (iOS)
2. **Android:** menu ⋮ → Adicionar à tela inicial
3. **iOS:** botão Compartilhar → Adicionar à Tela de Início

## Estrutura
```
triagem-app/
├── server.js          # Backend Express (proxy para API Claude)
├── package.json
├── public/
│   ├── index.html     # App PWA (frontend mobile)
│   ├── manifest.json  # Configuração PWA
│   ├── sw.js          # Service Worker (offline)
│   └── icons/         # Ícones do app
```
