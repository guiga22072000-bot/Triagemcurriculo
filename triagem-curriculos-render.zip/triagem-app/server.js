const express = require("express");
const multer  = require("multer");
const fetch   = require("node-fetch");
const cors    = require("cors");
const path    = require("path");

const app    = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ── Health check (Render usa isso) ──────────────────────────
app.get("/health", (_, res) => res.json({ ok: true }));

// ── Analyze one resume ──────────────────────────────────────
app.post("/analyze", upload.single("pdf"), async (req, res) => {
  const apiKey  = process.env.ANTHROPIC_API_KEY;
  const jobDesc = req.body.jobDesc || "";

  if (!apiKey)   return res.status(500).json({ error: "ANTHROPIC_API_KEY não configurada no servidor." });
  if (!req.file) return res.status(400).json({ error: "Nenhum arquivo PDF recebido." });
  if (!jobDesc)  return res.status(400).json({ error: "Requisitos da vaga não informados." });

  const base64 = req.file.buffer.toString("base64");

  const prompt = `Você é um recrutador experiente. Analise o currículo e retorne APENAS JSON válido (sem markdown, sem texto extra):
{
  "nome": "Nome Completo",
  "whatsapp": "telefone encontrado ou null",
  "status": "APROVADO" ou "REVISAR" ou "REPROVADO",
  "observacao": "1-2 frases sobre compatibilidade com a vaga"
}

Critérios:
- APROVADO: atende bem os requisitos principais
- REVISAR: atende parcialmente ou há dúvidas
- REPROVADO: não atende os requisitos principais

REQUISITOS DA VAGA:
${jobDesc}`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [{
          role: "user",
          content: [
            { type: "document", source: { type: "base64", media_type: "application/pdf", data: base64 } },
            { type: "text", text: prompt }
          ]
        }]
      })
    });

    const data = await response.json();
    if (data.error) return res.status(500).json({ error: data.error.message });

    const text   = data.content.map(c => c.text || "").join("").replace(/```json|```/g, "").trim();
    const result = JSON.parse(text);
    res.json(result);

  } catch (err) {
    console.error("Erro ao chamar Claude:", err);
    res.status(500).json({ error: "Falha na análise: " + err.message });
  }
});

// ── Fallback → serve index.html ─────────────────────────────
app.get("*", (_, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
